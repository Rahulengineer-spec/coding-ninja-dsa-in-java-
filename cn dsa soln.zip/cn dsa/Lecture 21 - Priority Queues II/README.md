### Extra References
1. [Changing default Min Priority Queue to Max Priority Queue](https://stackoverflow.com/questions/11003155/change-priorityqueue-to-max-priorityqueue)
