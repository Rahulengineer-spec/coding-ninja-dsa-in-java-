## Extra references to read about AVL Trees
1. https://www.cs.cmu.edu/~wlovas/15122-r11/lectures/18-avl.pdf
2. https://www.cs.mcgill.ca/~jeromew/teaching/251/F2020/COMP251_Lecture6_F2020.pdf
3. https://www.youtube.com/watch?v=mRGQylRWAsI&list=PLBF3763AF2E1C572F&index=11
4. https://www.youtube.com/watch?v=FNeL18KsWPc&list=PLUl4u3cNGP61Oq3tWYp6V_F-5jb5L2iHb&index=6
5. https://www.youtube.com/watch?v=jDM6_TnYIqE
6. https://brilliant.org/discussions/thread/avl-trees-meet-fibonacci-numbers/
7. http://people.csail.mit.edu/alinush/6.006-spring-2014/avl-height-proof.pdf
8. https://courses.cs.washington.edu/courses/cse373/19su/files/lectures/slides/lecture09.pdf
9. https://courses.csail.mit.edu/6.006/fall09/lecture_notes/lecture04.pdf
