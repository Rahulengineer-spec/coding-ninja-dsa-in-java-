### Extra Reading
1. [Graphs in Java | Baeldung](https://www.baeldung.com/java-graphs)
