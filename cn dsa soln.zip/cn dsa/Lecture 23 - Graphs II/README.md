### Extra Reading
1. [Union Find Algorithm](https://labuladong.gitbook.io/algo-en/iv.-high-frequency-interview-problem/union-find-explanation)
2. [Assignment - Detect cycles in undirected graphs](https://www.geeksforgeeks.org/detect-cycle-undirected-graph/)
