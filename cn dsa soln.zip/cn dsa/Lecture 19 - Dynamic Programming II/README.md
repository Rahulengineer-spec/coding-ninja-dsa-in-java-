### Extra Reading Material
1. [Assignment - Ways to Make Coin Change](https://www.geeksforgeeks.org/understanding-the-coin-change-problem-with-dynamic-programming/)
2. [Assignment - Subset Sum](https://www.geeksforgeeks.org/perfect-sum-problem-print-subsets-given-sum/)
3. [Assignment - Subset Sum](https://www.geeksforgeeks.org/subset-sum-problem-dp-25/)
