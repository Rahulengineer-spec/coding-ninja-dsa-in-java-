Extra Reading for the lecture
- [Bubble Sort Manually a Linked List in Java](https://stackoverflow.com/questions/29869094/bubble-sort-manually-a-linked-list-in-java)
