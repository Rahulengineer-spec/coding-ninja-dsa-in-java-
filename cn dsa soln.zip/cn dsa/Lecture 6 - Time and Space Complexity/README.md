## Extra References for Lecture 6
1. Derivation of Average Time Complexity for Quick Sort
  - https://www.cs.auckland.ac.nz/courses/compsci220s1c/lectures/2016S1C/CS220-Lecture10.pdf
  - http://www.hananayad.com/teaching/syde423/quickSortAvgCase.pdf
  - https://www.baeldung.com/cs/quicksort-time-complexity-worst-case
  - http://www.mathcs.emory.edu/~cheung/Courses/171/Syllabus/7-Sort/Quick-analysis.html
  - https://www.quora.com/What-is-the-sum-of-the-series-1+-1-2-+-1-3-+-1-4-+-1-5-up-to-infinity-How-can-it-be-calculated/answer/Avinash-Sahu-7

2. [Implementation of Quick Sort with different pivot elements (in C language)](https://www.codingeek.com/algorithms/quick-sort-algorithm-explanation-implementation-and-complexity/)
